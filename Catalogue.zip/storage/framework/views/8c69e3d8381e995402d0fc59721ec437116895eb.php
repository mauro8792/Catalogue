<?php $__env->startSection('title', 'Listado de categorías'); ?>

<?php $__env->startSection('body-class', 'product-page'); ?>

<?php $__env->startSection('content'); ?>
<div class="header header-filter" style="background-image: url('<?php echo e(asset('img/madera3.jpg')); ?>');">
</div>

<div class="main main-raised">
    <div class="container">
        <div class="section text-center">
            <h2 class="title">Listado de categorías</h2>
            <a href="<?php echo e(url('/admin/categories/create')); ?>" class="btn btn-warning btn-round t-black">Nueva categoría</a>
            <div class="team">
                <div class="row">

                    <?php if(count($categories)>0): ?>
                    <table class="table">
                        <thead>
                            <tr class="b-yellow">
                                <th class="col-md-2 text-center">Nombre</th>
                                <th class="col-md-5 text-center">Descripción</th>
                                <th>Imagen</th>
                                <th class="text-right">Opciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($category->name); ?></td>
                                <td><?php echo e($category->description); ?></td>
                                <td>
                                    <img src="<?php echo e($category->featured_image_url); ?>" height="50">
                                </td>
                                <td class="td-actions text-right">
                                    <a href="#" rel="tooltip" title="Ver categoría"><i class="fa fa-info font24 t-blue"></i></a>&nbsp;&nbsp;
                                    <a href="<?php echo e(url('/admin/categories/'.$category->id.'/edit')); ?>" rel="tooltip" title="Editar categoría"><i class="fa fa-edit font24 t-yellow"></i></a>&nbsp;&nbsp;
                                    <a href="<?php echo e(url('/admin/categories/'.$category->id.'/del')); ?>" rel="tooltip" title="Eliminar"><i class="fa fa-times font24 t-red"></i></a>&nbsp;&nbsp;
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php echo e($categories->links()); ?>

                    <?php else: ?>
                        <h4>No hay categorias cargadas</h4>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>