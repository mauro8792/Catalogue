<footer class="footer b-yellow">
    <div class="container">
        <div class="copyright pull-left">
            <ul >
                <li >Patuto & Co. &copy; 2019</li>
            </ul>
        </div>
    </div>
</footer>