    <nav class="navbar navbar-warning navbar-absolute">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <?php if(Request::path()!='/'): ?>
                   <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('images/logo.jpg')); ?>" alt="Patuto & Co." class="img-responsive" width="150"></a>
                <?php endif; ?>
            </div>

            <div class="collapse navbar-collapse text-default" id="navigation-example">
                <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="">&nbsp</a>
                        </li>
                    <?php if(auth()->guard()->guest()): ?>
                        <li><a href="<?php echo e(route('login')); ?>" class="t-black">Ingresar</a></li>
                        <li><a href="<?php echo e(route('register')); ?>" class="t-black">Registro</a></li>
                    <?php else: ?>

                    <?php if(auth()->user()->admin): ?>
                        <li>
                            <a href="<?php echo e(url('/admin/categories')); ?>" class="t-black">Categorias</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/admin/products')); ?>" class="t-black">Productos</a>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle t-black" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                    <?php endif; ?>
                                <li>
                                    <a href="<?php echo e(route('logout')); ?>" class="t-black"
                                        onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        Cerrar sesion
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
